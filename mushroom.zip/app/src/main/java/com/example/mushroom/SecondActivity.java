package com.example.mushroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class SecondActivity extends Activity {
    int count = 0;
    int shape = 0;              //버섯 갓 모양
    int surface = 0;            //버섯 갓 표면
    int color = 0;              //버섯 갓 색상
    int bruise= 0;              //버섯의 멍, 흠집
    int odor = 0;               //버섯의 냄새
    int attachment = 0;         //버섯 주름살 모양
    int spacing = 0;            //버섯 주름 너비
    int size = 0;               //버섯 주름 크기
    int g_color = 0;            //버섯 주름 색상
    int s_shape = 0;            //버섯 줄기 모양
    int root  = 0;              //버섯 줄기 뿌리
    int stalk_above_ring = 0;   //버섯 줄기 표면 윗부분 표면
    int stalk_below_ring = 0;   //버섯 줄기 표면 아랫부분 표면
    int sc_above_ring = 0;      //버섯 줄기 윗부분 색상
    int sc_below_ring = 0;      //버섯 줄기 아랫부분 색상
    int veil_type = 0;          //베일 유형
    int veil_color = 0;         //베일 색상
    int ring_number = 0;        //고리 개수
    int ring_type = 0;          //고리 유형
    int spore_print_color = 0;  //포자 색상
    int population = 0;         //개체군
    int habit = 0;              //발견 장소


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("Second");

        //이전 다음 마지막
        Button before, next, result;

        //버섯 갓 모양
        TextView bell, conical, flat, knob, sunken, convex;
        //버섯 갓 표면
        TextView fibrous, grooves, smooth, scaly;
        //버섯 갓 색상
        TextView buff, cinnamon, red, gray,  brown, pink, green, purple, white, yellow;
        //버섯 갓 멍, 흠집 유무
        TextView bruises;
        //버섯 냄새
        TextView almond, creosote, foul, anise, musty, none, pungent, spicy, fishy;
        //버섯 주름살 모양
        TextView attach, free;
        //버섯 주름 너비
        TextView close, crowded;
        //버섯 주름 크기
        TextView broad, narrow;
        //주름 색상
        TextView g_black, g_brown, g_buff, g_choco, g_gray, g_green, g_orange, g_pink, g_purple, g_red, g_white, g_yellow;
        //줄기 모양
        TextView enlarging, tapering;
        //줄기 뿌리
        TextView bulbous, club, equal, rooted, missing;
        //줄기 표면 윗부분 표면
        TextView su_fibrous, su_scaly, su_silky, su_smooths;
        //줄기 표면 아랫부분 표면
        TextView sd_fibrous, sd_scaly, sd_silky, sd_smooths;
        //줄기 윗부분 색상
        TextView scu_brown, scu_buff, scu_cinnamon, scu_gray, scu_orange, scu_pink, scu_red, scu_white, scu_yellow;
        //줄기 아랫부분 색상
        TextView scd_brown, scd_buff, scd_cinnamon, scd_gray, scd_orange, scd_pink, scd_red, scd_white, scd_yellow;
        //베일 유형
        TextView partial, universal;
        //베일 색상
        TextView vc_brown, vc_orange, vc_white, vc_yellow;
        //고리 번호
        TextView num_none, num_one, num_two;
        //고리 유형
        TextView cobwebby, evanescent, flaring, large, rt_none, pendant, sheathing, zone;
        //포자 색상
        TextView sp_black, sp_brown, sp_buff, sp_choco, sp_green, sp_orange, sp_purple, sp_white, sp_yellow;
        //개체군
        TextView abundant, clustered, numerous, scattered, several, solitary;
        //발견 장소
        TextView grasses, leaves, meadows, paths, urban, waste, woods;


        ViewFlipper flipper;

        flipper = (ViewFlipper) findViewById(R.id.flipper);
        before = (Button) findViewById(R.id.before);
        next = (Button) findViewById(R.id.next);
        result = (Button) findViewById(R.id.result);

        //버섯 갓 모양
        bell = (TextView) findViewById(R.id.bell);
        conical = (TextView) findViewById(R.id.conical);
        flat = (TextView) findViewById(R.id.flat);
        knob = (TextView) findViewById(R.id.knob);
        sunken = (TextView) findViewById(R.id.sunken);
        convex = (TextView) findViewById(R.id.convex);

        bell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 0;
            }
        });
        conical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 1;
            }
        });
        flat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 2;
            }
        });
        knob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 3;
            }
        });
        sunken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 4;
            }
        });
        convex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 5;
            }
        });

        //버섯 갓 표면
        fibrous = (TextView) findViewById(R.id.fibrous);
        grooves = (TextView) findViewById(R.id.grooves);
        smooth = (TextView) findViewById(R.id.smooth);
        scaly = (TextView) findViewById(R.id.scaly);

        fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 0;
            }
        });
        grooves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 1;
            }
        });
        smooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 2;
            }
        });
        scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 3;
            }
        });

        //버섯 갓 색상
        buff = (TextView) findViewById(R.id.buff);
        cinnamon = (TextView) findViewById(R.id.cinnamon);
        red= (TextView) findViewById(R.id.red);
        gray = (TextView) findViewById(R.id.gray);
        brown = (TextView) findViewById(R.id.brown);
        pink = (TextView) findViewById(R.id.pink);
        green = (TextView) findViewById(R.id.green);
        purple = (TextView) findViewById(R.id.purple);
        white = (TextView) findViewById(R.id.white);
        yellow = (TextView) findViewById(R.id.yellow);

        buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 0;
            }
        });
        cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 1;
            }
        });
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 2;
            }
        });
        gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 3;
            }
        });
        brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 4;
            }
        });
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 5;
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 6;
            }
        });
        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 7;
            }
        });
        white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 8;
            }
        });
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 9;
            }
        });

        //버섯 갓 손상 유무
        bruises = (TextView) findViewById(R.id.bruises);

        bruises.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bruise = 0;
            }
        });

        //버섯 냄새
        almond = (TextView) findViewById(R.id.almond);
        creosote = (TextView) findViewById(R.id.creosote);
        foul = (TextView) findViewById(R.id.foul);
        anise = (TextView) findViewById(R.id.anise);
        musty = (TextView) findViewById(R.id.musty);
        none= (TextView) findViewById(R.id.none);
        pungent = (TextView) findViewById(R.id.pungent);
        spicy = (TextView) findViewById(R.id.spicy);
        fishy = (TextView) findViewById(R.id.fishy);

        almond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 0;
            }
        });
        creosote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 1;
            }
        });
        foul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 2;
            }
        });
        anise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 3;
            }
        });
        musty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 4;
            }
        });
        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 5;
            }
        });
        pungent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 6;
            }
        });
        spicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 7;
            }
        });
        fishy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 8;
            }
        });

        //버섯 주름살 모양
        attach = (TextView) findViewById(R.id.attach);
        free = (TextView) findViewById(R.id.free);

        attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attachment = 0;
            }
        });
        free.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attachment = 1;
            }
        });

        //버섯 주름 너비
        close = (TextView) findViewById(R.id.close);
        crowded = (TextView) findViewById(R.id.crowded);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spacing = 0;
            }
        });
        crowded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spacing = 1;
            }
        });

        //버섯 주름 크기
        broad = (TextView) findViewById(R.id.broad);
        narrow = (TextView) findViewById(R.id.narrow);

        broad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
            }
        });
        narrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
            }
        });

        //주름 색상
        g_buff = (TextView) findViewById(R.id.g_buff);
        g_red = (TextView) findViewById(R.id.g_red);
        g_gray = (TextView) findViewById(R.id.g_gray);
        g_choco = (TextView) findViewById(R.id.g_choco);
        g_black = (TextView) findViewById(R.id.g_black);
        g_brown = (TextView) findViewById(R.id.g_brown);
        g_orange = (TextView) findViewById(R.id.g_orange);
        g_pink = (TextView) findViewById(R.id.g_pink);
        g_green = (TextView) findViewById(R.id.g_green);
        g_purple = (TextView) findViewById(R.id.g_purple);
        g_white = (TextView) findViewById(R.id.g_white);
        g_yellow = (TextView) findViewById(R.id.g_yellow);

        g_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 0;
            }
        });
        g_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 1;
            }
        });
        g_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 2;
            }
        });
        g_choco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 3;
            }
        });
        g_black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 4;
            }
        });
        g_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 5;
            }
        });
        g_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 6;
            }
        });
        g_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 7;
            }
        });
        g_green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 8;
            }
        });
        g_purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 9;
            }
        });
        g_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 10;
            }
        });
        g_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 11;
            }
        });

        //줄기 모양
        enlarging = (TextView) findViewById(R.id.enlarging);
        tapering = (TextView) findViewById(R.id.tapering);

        enlarging.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_shape = 0;
            }
        });
        tapering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_shape = 0;
            }
        });

        //줄기 뿌리
        missing = (TextView) findViewById(R.id.missing);
        bulbous = (TextView) findViewById(R.id.bulbous);
        club = (TextView) findViewById(R.id.club);
        equal = (TextView) findViewById(R.id.equal);
        rooted = (TextView) findViewById(R.id.rooted);

        missing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 0;
            }
        });
        bulbous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 1;
            }
        });
        club.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 2;
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 3;
            }
        });
        rooted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 4;
            }
        });


        //줄기 윗부분 표면
        su_fibrous = (TextView) findViewById(R.id.su_fibrous);
        su_silky = (TextView) findViewById(R.id.su_silky);
        su_smooths = (TextView) findViewById(R.id.su_smooth);
        su_scaly = (TextView) findViewById(R.id.su_scaly);

        su_fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 0;
            }
        });
        su_silky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 1;
            }
        });
        su_smooths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 2;
            }
        });
        su_scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 3;
            }
        });

        //줄기 아랫부분 포면
        sd_fibrous = (TextView) findViewById(R.id.sd_fibrous);
        sd_silky = (TextView) findViewById(R.id.sd_silky);
        sd_smooths = (TextView) findViewById(R.id.sd_smooth);
        sd_scaly = (TextView) findViewById(R.id.sd_scaly);

        sd_fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 0;
            }
        });
        sd_silky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 1;
            }
        });
        sd_smooths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 2;
            }
        });
        sd_scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 3;
            }
        });

        //줄기 윗부분 색상
        scu_buff = (TextView) findViewById(R.id.scu_buff);
        scu_cinnamon = (TextView) findViewById(R.id.scu_cinnamon);
        scu_red = (TextView) findViewById(R.id.scu_red);
        scu_gray = (TextView) findViewById(R.id.scu_gray);
        scu_brown = (TextView) findViewById(R.id.scu_brown);
        scu_orange = (TextView) findViewById(R.id.scu_orange);
        scu_pink = (TextView) findViewById(R.id.scu_pink);
        scu_white = (TextView) findViewById(R.id.scu_white);
        scu_yellow = (TextView) findViewById(R.id.scu_yellow);

        scu_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 0;
            }
        });
        scu_cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 1;
            }
        });
        scu_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 2;
            }
        });
        scu_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 3;
            }
        });
        scu_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 4;
            }
        });
        scu_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 5;
            }
        });
        scu_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 6;
            }
        });
        scu_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 7;
            }
        });
        scu_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 8;
            }
        });

        //줄기 아랫부분 색상

        scd_buff = (TextView) findViewById(R.id.scd_buff);
        scd_cinnamon = (TextView) findViewById(R.id.scd_cinnamon);
        scd_red = (TextView) findViewById(R.id.scd_red);
        scd_gray = (TextView) findViewById(R.id.scd_gray);
        scd_brown = (TextView) findViewById(R.id.scd_brown);
        scd_orange = (TextView) findViewById(R.id.scd_orange);
        scd_pink = (TextView) findViewById(R.id.scd_pink);
        scd_white = (TextView) findViewById(R.id.scd_white);
        scd_yellow = (TextView) findViewById(R.id.scd_yellow);

        scd_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 0;
            }
        });
        scd_cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 1;
            }
        });
        scd_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 2;
            }
        });
        scd_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 3;
            }
        });
        scd_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 4;
            }
        });
        scd_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 5;
            }
        });
        scd_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 6;
            }
        });
        scd_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 7;
            }
        });
        scd_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 8;
            }
        });

        //베일 유형
        partial = (TextView) findViewById(R.id.partial);
        //universal = (TextView) findViewById(R.id.universal);

        partial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_type = 1;
            }
        });
        /*universal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
            }
        });*/

        //베일 색상
        vc_brown = (TextView) findViewById(R.id.vc_brown);
        vc_orange = (TextView) findViewById(R.id.vc_orange);
        vc_white = (TextView) findViewById(R.id.vc_white);
        vc_yellow = (TextView) findViewById(R.id.vc_yellow);

        vc_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 0;
            }
        });
        vc_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 1;
            }
        });
        vc_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 2;
            }
        });
        vc_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 3;
            }
        });

        //고리 갯수
        num_none = (TextView) findViewById(R.id.num_none);
        num_one = (TextView) findViewById(R.id.num_one);
        num_two = (TextView) findViewById(R.id.num_two);

        num_none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 0;
            }
        });
        num_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 1;
            }
        });
        num_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 2;
            }
        });

        //고리 유형
        //cobwebby = (TextView) findViewById(R.id.cobwebby);
        evanescent = (TextView) findViewById(R.id.evanescent);
        flaring = (TextView) findViewById(R.id.flaring);
        large = (TextView) findViewById(R.id.large);
        rt_none = (TextView) findViewById(R.id.rt_none);
        pendant = (TextView) findViewById(R.id.pendant);
        //sheathing = (TextView) findViewById(R.id.sheathing);
        //zone = (TextView) findViewById(R.id.zone);

        /*cobwebby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
            }
        });*/
        evanescent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 0;
            }
        });
        flaring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 1;
            }
        });
        large.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 2;
            }
        });
        rt_none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 3;
            }
        });
        pendant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 4;
            }
        });
        /*sheathing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
            }
        });*/
        /*zone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
            }
        });*/

        //포자 색상
        sp_buff = (TextView) findViewById(R.id.sp_buff);
        sp_choco = (TextView) findViewById(R.id.sp_choco);
        sp_black = (TextView) findViewById(R.id.sp_black);
        sp_brown = (TextView) findViewById(R.id.sp_brown);
        sp_orange = (TextView) findViewById(R.id.sp_orange);
        sp_green = (TextView) findViewById(R.id.sp_green);
        sp_purple = (TextView) findViewById(R.id.sp_purple);
        sp_white = (TextView) findViewById(R.id.sp_white);
        sp_yellow = (TextView) findViewById(R.id.sp_yellow);


        sp_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 0;
            }
        });
        sp_choco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 1;
            }
        });
        sp_black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 2;
            }
        });
        sp_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 3;
            }
        });
        sp_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 4;
            }
        });
        sp_green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 5;
            }
        });
        sp_purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 6;
            }
        });
        sp_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 7;
            }
        });
        sp_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 8;
            }
        });

        //개체군
        abundant = (TextView) findViewById(R.id.abundant);
        clustered = (TextView) findViewById(R.id.clustered);
        numerous = (TextView) findViewById(R.id.numerous);
        scattered = (TextView) findViewById(R.id.scattered);
        several = (TextView) findViewById(R.id.several);
        solitary = (TextView) findViewById(R.id.solitary);

        abundant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 0;
            }
        });
        clustered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 1;
            }
        });
        numerous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 2;
            }
        });
        scattered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 3;
            }
        });
        several.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 4;
            }
        });
        solitary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 5;
            }
        });

        //발견 장소
        woods = (TextView) findViewById(R.id.woods);
        grasses = (TextView) findViewById(R.id.grasses);
        leaves = (TextView) findViewById(R.id.leaves);
        meadows = (TextView) findViewById(R.id.meadows);
        paths = (TextView) findViewById(R.id.paths);
        urban = (TextView) findViewById(R.id.urban);
        waste = (TextView) findViewById(R.id.waste);

        woods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 0;
            }
        });
        grasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 1;
            }
        });
        leaves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 2;
            }
        });
        meadows.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 3;
            }
        });
        paths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 4;
            }
        });
        urban.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 5;
            }
        });
        waste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 6;
            }
        });


        //이전 다음 감별 버튼
        before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipper.showPrevious();
                count--;
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipper.showNext();
                if (count == 0){
                    before.setVisibility(View.VISIBLE);}
                count++;
                if (count == 20){
                    next.setVisibility(View.GONE);
                    result.setVisibility(View.VISIBLE);}

            }
        });
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LastActivity.class);
                startActivity(intent);
            }
        });
    }
}
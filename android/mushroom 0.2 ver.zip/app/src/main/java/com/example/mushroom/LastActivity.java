package com.example.mushroom;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LastActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last);
        setTitle("last");

        String value = getIntent().getStringExtra("value");

        Button firstpage = (Button) findViewById(R.id.firstpage);
        ImageView eat = (ImageView) findViewById(R.id.eat);

        Intent thirdintent = new Intent(this, MainActivity.class);


        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                try {
//                    String restapi = "http://192.168.0.5:8000/predict/"; // 3%2C4%2C5
//                    restapi = restapi + value;
//
//
//                    // Open the connection
//                    URL url = new URL(restapi);
//
//                    /////////////////TEST_URL/////////////////
//
//                    //URL url = new URL("http://192.168.0.5:8000/predict/0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0"); // 1
//                    //URL url = new URL("http://192.168.0.5:8000/predict/5,2,9,1,0,1,0,0,4,0,2,2,2,7,7,0,2,1,4,3,2,1"); //0
//
//                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
//                    conn.setRequestMethod("GET");
//                    InputStream is = conn.getInputStream();//??
//
//
//                    // Get the stream
//                    StringBuilder builder = new StringBuilder();
//                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
//                    String line;
//                    while ((line = reader.readLine()) != null) {
//                        builder.append(line);
//                    }
//
//                    // Set the result
//                    String resultt = builder.toString();
                    String resultt = "\"0\"";
                    if(resultt.equals("\"0\"")){
                        // 먹을수 있을때 사진
                        eat.setImageResource(R.drawable.squid);
                    }else {
                        // 먹을수 없을때 사진
                        eat.setImageResource(R.drawable.girl);
                    }
                }
                catch (Exception e) {
                    // Error calling the rest api
                    Log.e("REST_API", "GET method failed: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
        
        firstpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(thirdintent);
            }
        });

    }

}

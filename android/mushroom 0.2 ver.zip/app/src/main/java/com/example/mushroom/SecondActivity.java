package com.example.mushroom;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class SecondActivity extends Activity {
    int count = 0;
    int shape = 0;              //버섯 갓 모양
    int surface = 0;            //버섯 갓 표면
    int color = 0;              //버섯 갓 색상
    int bruise = 0;              //버섯의 멍, 흠집
    int odor = 0;               //버섯의 냄새
    int attachment = 0;         //버섯 주름살 모양
    int spacing = 0;            //버섯 주름 너비
    int size = 0;               //버섯 주름 크기
    int g_color = 0;            //버섯 주름 색상
    int s_shape = 0;            //버섯 줄기 모양
    int root = 0;              //버섯 줄기 뿌리
    int stalk_above_ring = 0;   //버섯 줄기 표면 윗부분 표면
    int stalk_below_ring = 0;   //버섯 줄기 표면 아랫부분 표면
    int sc_above_ring = 0;      //버섯 줄기 윗부분 색상
    int sc_below_ring = 0;      //버섯 줄기 아랫부분 색상
    int veil_type = 0;          //베일 유형
    int veil_color = 0;         //베일 색상
    int ring_number = 0;        //고리 개수
    int ring_type = 0;          //고리 유형
    int spore_print_color = 0;  //포자 색상
    int population = 0;         //개체군
    int habit = 0;              //발견 장소

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("Second");

        //이전 다음 마지막
        Button before, next, result;

        //버섯 갓 모양
        Button bell, conical, flat, knob, sunken, convex;
        //버섯 갓 표면
        Button fibrous, grooves, smooth, scaly;
        //버섯 갓 색상
        Button buff, cinnamon, red, gray, brown, pink, green, purple, white, yellow;
        //버섯 갓 멍, 흠집 유무
        Button bruises;
        //버섯 냄새
        Button almond, creosote, foul, anise, musty, none, pungent, spicy, fishy;
        //버섯 주름살 모양
        Button attach, free;
        //버섯 주름 너비
        Button close, crowded;
        //버섯 주름 크기
        Button broad, narrow;
        //주름 색상
        Button g_black, g_brown, g_buff, g_choco, g_gray, g_green, g_orange, g_pink, g_purple, g_red, g_white, g_yellow;
        //줄기 모양
        Button enlarging, tapering;
        //줄기 뿌리
        Button bulbous, club, equal, rooted, missing;
        //줄기 표면 윗부분 표면
        Button su_fibrous, su_scaly, su_silky, su_smooths;
        //줄기 표면 아랫부분 표면
        Button sd_fibrous, sd_scaly, sd_silky, sd_smooths;
        //줄기 윗부분 색상
        Button scu_brown, scu_buff, scu_cinnamon, scu_gray, scu_orange, scu_pink, scu_red, scu_white, scu_yellow;
        //줄기 아랫부분 색상
        Button scd_brown, scd_buff, scd_cinnamon, scd_gray, scd_orange, scd_pink, scd_red, scd_white, scd_yellow;
        //베일 유형
        Button partial, universal;
        //베일 색상
        Button vc_brown, vc_orange, vc_white, vc_yellow;
        //고리 번호
        Button num_none, num_one, num_two;
        //고리 유형
        Button cobwebby, evanescent, flaring, large, rt_none, pendant, sheathing, zone;
        //포자 색상
        Button sp_black, sp_brown, sp_buff, sp_choco, sp_green, sp_orange, sp_purple, sp_white, sp_yellow;
        //개체군
        Button abundant, clustered, numerous, scattered, several, solitary;
        //발견 장소
        Button grasses, leaves, meadows, paths, urban, waste, woods;
        //페이지별 이미지
        ImageView page1, page2, page3, page4, page5, page6, page7, page8, page9, page10, page11, page12, page13, page14, page15, page16, page17, page18, page19, page20, page21, page22;


        ViewFlipper flipper;


        flipper = (ViewFlipper) findViewById(R.id.flipper);
        before = (Button) findViewById(R.id.before);
        next = (Button) findViewById(R.id.next);
        result = (Button) findViewById(R.id.result);

        //버섯 갓 모양
        bell = (Button) findViewById(R.id.bell);
        conical = (Button) findViewById(R.id.conical);
        flat = (Button) findViewById(R.id.flat);
        knob = (Button) findViewById(R.id.knob);
        sunken = (Button) findViewById(R.id.sunken);
        convex = (Button) findViewById(R.id.convex);

        page1 = (ImageView) findViewById(R.id.page1); //사진

        bell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 0;
                page1.setImageResource(R.drawable.squid);
            }
        });
        conical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 1;
                page1.setImageResource(R.drawable.squid);
            }
        });
        flat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 2;
                page1.setImageResource(R.drawable.girl);
            }
        });
        knob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 3;
                page1.setImageResource(R.drawable.squid);
            }
        });
        sunken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 4;
                page1.setImageResource(R.drawable.squid);
            }
        });
        convex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shape = 5;
                page1.setImageResource(R.drawable.squid);
            }
        });

        //버섯 갓 표면
        fibrous = (Button) findViewById(R.id.fibrous);
        grooves = (Button) findViewById(R.id.grooves);
        smooth = (Button) findViewById(R.id.smooth);
        scaly = (Button) findViewById(R.id.scaly);

        page2 = (ImageView) findViewById(R.id.page2); //사진

        fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 0;
                page2.setImageResource(R.drawable.squid);
            }
        });
        grooves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 1;
                page2.setImageResource(R.drawable.squid);
            }
        });
        smooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 2;
                page2.setImageResource(R.drawable.squid);
            }
        });
        scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                surface = 3;
                page2.setImageResource(R.drawable.squid);
            }
        });

        //버섯 갓 색상
        buff = (Button) findViewById(R.id.buff);
        cinnamon = (Button) findViewById(R.id.cinnamon);
        red = (Button) findViewById(R.id.red);
        gray = (Button) findViewById(R.id.gray);
        brown = (Button) findViewById(R.id.brown);
        pink = (Button) findViewById(R.id.pink);
        green = (Button) findViewById(R.id.green);
        purple = (Button) findViewById(R.id.purple);
        white = (Button) findViewById(R.id.white);
        yellow = (Button) findViewById(R.id.yellow);

        page3 = (ImageView) findViewById(R.id.page3); //사진

        buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 0;
                page3.setImageResource(R.drawable.squid);
            }
        });
        cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 1;
                page3.setImageResource(R.drawable.squid);
            }
        });
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 2;
                page3.setImageResource(R.drawable.squid);
            }
        });
        gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 3;
                page3.setImageResource(R.drawable.squid);
            }
        });
        brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 4;
                page3.setImageResource(R.drawable.squid);
            }
        });
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 5;
                page3.setImageResource(R.drawable.squid);
            }
        });
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 6;
                page3.setImageResource(R.drawable.squid);
            }
        });
        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 7;
                page3.setImageResource(R.drawable.squid);
            }
        });
        white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 8;
                page3.setImageResource(R.drawable.squid);
            }
        });
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color = 9;
                page3.setImageResource(R.drawable.squid);
            }
        });

        //버섯 갓 손상 유무
        bruises = (Button) findViewById(R.id.bruises);

        page4 = (ImageView) findViewById(R.id.page4); //사진

        bruises.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bruise = 0;
                page4.setImageResource(R.drawable.squid);
            }
        });

        //버섯 냄새
        almond = (Button) findViewById(R.id.almond);
        creosote = (Button) findViewById(R.id.creosote);
        foul = (Button) findViewById(R.id.foul);
        anise = (Button) findViewById(R.id.anise);
        musty = (Button) findViewById(R.id.musty);
        none = (Button) findViewById(R.id.none);
        pungent = (Button) findViewById(R.id.pungent);
        spicy = (Button) findViewById(R.id.spicy);
        fishy = (Button) findViewById(R.id.fishy);

        page5 = (ImageView) findViewById(R.id.page5); //사진

        almond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 0;
                page5.setImageResource(R.drawable.squid);
            }
        });
        creosote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 1;
                page5.setImageResource(R.drawable.squid);
            }
        });
        foul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 2;
                page5.setImageResource(R.drawable.squid);
            }
        });
        anise.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 3;
                page5.setImageResource(R.drawable.squid);
            }
        });
        musty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 4;
                page5.setImageResource(R.drawable.squid);
            }
        });
        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 5;
                page5.setImageResource(R.drawable.squid);
            }
        });
        pungent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 6;
                page5.setImageResource(R.drawable.squid);
            }
        });
        spicy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 7;
                page5.setImageResource(R.drawable.squid);
            }
        });
        fishy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                odor = 8;
                page5.setImageResource(R.drawable.squid);
            }
        });

        //버섯 주름살 모양
        attach = (Button) findViewById(R.id.attach);
        free = (Button) findViewById(R.id.free);

        page6 = (ImageView) findViewById(R.id.page6); //사진

        attach.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attachment = 0;
                page6.setImageResource(R.drawable.squid);
            }
        });
        free.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attachment = 1;
                page6.setImageResource(R.drawable.squid);
            }
        });

        //버섯 주름 너비
        close = (Button) findViewById(R.id.close);
        crowded = (Button) findViewById(R.id.crowded);

        page7 = (ImageView) findViewById(R.id.page7); //사진

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spacing = 0;
                page7.setImageResource(R.drawable.squid);
            }
        });
        crowded.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spacing = 1;
                page7.setImageResource(R.drawable.squid);
            }
        });

        //버섯 주름 크기
        broad = (Button) findViewById(R.id.broad);
        narrow = (Button) findViewById(R.id.narrow);

        page8 = (ImageView) findViewById(R.id.page8); //사진

        broad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
                page8.setImageResource(R.drawable.squid);
            }
        });
        narrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
                page8.setImageResource(R.drawable.squid);
            }
        });

        //주름 색상
        g_buff = (Button) findViewById(R.id.g_buff);
        g_red = (Button) findViewById(R.id.g_red);
        g_gray = (Button) findViewById(R.id.g_gray);
        g_choco = (Button) findViewById(R.id.g_choco);
        g_black = (Button) findViewById(R.id.g_black);
        g_brown = (Button) findViewById(R.id.g_brown);
        g_orange = (Button) findViewById(R.id.g_orange);
        g_pink = (Button) findViewById(R.id.g_pink);
        g_green = (Button) findViewById(R.id.g_green);
        g_purple = (Button) findViewById(R.id.g_purple);
        g_white = (Button) findViewById(R.id.g_white);
        g_yellow = (Button) findViewById(R.id.g_yellow);

        page9 = (ImageView) findViewById(R.id.page9); //사진

        g_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 0;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 1;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 2;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_choco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 3;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 4;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 5;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 6;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 7;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 8;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 9;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 10;
                page9.setImageResource(R.drawable.squid);
            }
        });
        g_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                g_color = 11;
                page9.setImageResource(R.drawable.squid);
            }
        });

        //줄기 모양
        enlarging = (Button) findViewById(R.id.enlarging);
        tapering = (Button) findViewById(R.id.tapering);

        page10 = (ImageView) findViewById(R.id.page10); //사진

        enlarging.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_shape = 0;
                page10.setImageResource(R.drawable.squid);
            }
        });
        tapering.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_shape = 1;
                page10.setImageResource(R.drawable.squid);
            }
        });

        //줄기 뿌리
        missing = (Button) findViewById(R.id.missing);
        bulbous = (Button) findViewById(R.id.bulbous);
        club = (Button) findViewById(R.id.club);
        equal = (Button) findViewById(R.id.equal);
        rooted = (Button) findViewById(R.id.rooted);

        page11 = (ImageView) findViewById(R.id.page11); //사진

        missing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 0;
                page11.setImageResource(R.drawable.squid);
            }
        });
        bulbous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 1;
                page11.setImageResource(R.drawable.squid);
            }
        });
        club.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 2;
                page11.setImageResource(R.drawable.squid);
            }
        });
        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 3;
                page11.setImageResource(R.drawable.squid);
            }
        });
        rooted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                root = 4;
                page11.setImageResource(R.drawable.squid);
            }
        });


        //줄기 윗부분 표면
        su_fibrous = (Button) findViewById(R.id.su_fibrous);
        su_silky = (Button) findViewById(R.id.su_silky);
        su_smooths = (Button) findViewById(R.id.su_smooth);
        su_scaly = (Button) findViewById(R.id.su_scaly);

        page12 = (ImageView) findViewById(R.id.page12); //사진

        su_fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 0;
                page12.setImageResource(R.drawable.squid);
            }
        });
        su_silky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 1;
                page12.setImageResource(R.drawable.squid);
            }
        });
        su_smooths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 2;
                page12.setImageResource(R.drawable.squid);
            }
        });
        su_scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_above_ring = 3;
                page12.setImageResource(R.drawable.squid);
            }
        });

        //줄기 아랫부분 포면
        sd_fibrous = (Button) findViewById(R.id.sd_fibrous);
        sd_silky = (Button) findViewById(R.id.sd_silky);
        sd_smooths = (Button) findViewById(R.id.sd_smooth);
        sd_scaly = (Button) findViewById(R.id.sd_scaly);

        page13 = (ImageView) findViewById(R.id.page13); //사진

        sd_fibrous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 0;
                page13.setImageResource(R.drawable.squid);
            }
        });
        sd_silky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 1;
                page13.setImageResource(R.drawable.squid);
            }
        });
        sd_smooths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 2;
                page13.setImageResource(R.drawable.squid);
            }
        });
        sd_scaly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stalk_below_ring = 3;
                page13.setImageResource(R.drawable.squid);
            }
        });

        //줄기 윗부분 색상
        scu_buff = (Button) findViewById(R.id.scu_buff);
        scu_cinnamon = (Button) findViewById(R.id.scu_cinnamon);
        scu_red = (Button) findViewById(R.id.scu_red);
        scu_gray = (Button) findViewById(R.id.scu_gray);
        scu_brown = (Button) findViewById(R.id.scu_brown);
        scu_orange = (Button) findViewById(R.id.scu_orange);
        scu_pink = (Button) findViewById(R.id.scu_pink);
        scu_white = (Button) findViewById(R.id.scu_white);
        scu_yellow = (Button) findViewById(R.id.scu_yellow);

        page14 = (ImageView) findViewById(R.id.page14); //사진

        scu_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 0;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 1;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 2;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 3;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 4;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 5;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 6;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 7;
                page14.setImageResource(R.drawable.squid);
            }
        });
        scu_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_above_ring = 8;
                page14.setImageResource(R.drawable.squid);
            }
        });

        //줄기 아랫부분 색상
        scd_buff = (Button) findViewById(R.id.scd_buff);
        scd_cinnamon = (Button) findViewById(R.id.scd_cinnamon);
        scd_red = (Button) findViewById(R.id.scd_red);
        scd_gray = (Button) findViewById(R.id.scd_gray);
        scd_brown = (Button) findViewById(R.id.scd_brown);
        scd_orange = (Button) findViewById(R.id.scd_orange);
        scd_pink = (Button) findViewById(R.id.scd_pink);
        scd_white = (Button) findViewById(R.id.scd_white);
        scd_yellow = (Button) findViewById(R.id.scd_yellow);

        page15 = (ImageView) findViewById(R.id.page15); //사진

        scd_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 0;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_cinnamon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 1;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 2;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_gray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 3;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 4;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 5;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 6;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 7;
                page15.setImageResource(R.drawable.squid);
            }
        });
        scd_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sc_below_ring = 8;
                page15.setImageResource(R.drawable.squid);
            }
        });

        //베일 유형
        partial = (Button) findViewById(R.id.partial);
        //universal = (Button) findViewById(R.id.universal);

        page16 = (ImageView) findViewById(R.id.page16); //사진

        partial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_type = 1;
                page16.setImageResource(R.drawable.squid);
            }
        });
        /*universal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
            }
        });*/

        //베일 색상
        vc_brown = (Button) findViewById(R.id.vc_brown);
        vc_orange = (Button) findViewById(R.id.vc_orange);
        vc_white = (Button) findViewById(R.id.vc_white);
        vc_yellow = (Button) findViewById(R.id.vc_yellow);

        page17 = (ImageView) findViewById(R.id.page17); //사진

        vc_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 0;
                page17.setImageResource(R.drawable.squid);
            }
        });
        vc_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 1;
                page17.setImageResource(R.drawable.squid);
            }
        });
        vc_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 2;
                page17.setImageResource(R.drawable.squid);
            }
        });
        vc_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veil_color = 3;
                page17.setImageResource(R.drawable.squid);
            }
        });

        //고리 갯수
        num_none = (Button) findViewById(R.id.num_none);
        num_one = (Button) findViewById(R.id.num_one);
        num_two = (Button) findViewById(R.id.num_two);

        page18 = (ImageView) findViewById(R.id.page18); //사진

        num_none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 0;
                page18.setImageResource(R.drawable.squid);
            }
        });
        num_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 1;
                page18.setImageResource(R.drawable.squid);
            }
        });
        num_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_number = 2;
                page18.setImageResource(R.drawable.squid);
            }
        });

        //고리 유형
        //cobwebby = (Button) findViewById(R.id.cobwebby);
        evanescent = (Button) findViewById(R.id.evanescent);
        flaring = (Button) findViewById(R.id.flaring);
        large = (Button) findViewById(R.id.large);
        rt_none = (Button) findViewById(R.id.rt_none);
        pendant = (Button) findViewById(R.id.pendant);
        //sheathing = (Button) findViewById(R.id.sheathing);
        //zone = (Button) findViewById(R.id.zone);

        page19 = (ImageView) findViewById(R.id.page19); //사진

        /*cobwebby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
            }
        });*/
        evanescent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 0;
                page19.setImageResource(R.drawable.squid);
            }
        });
        flaring.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 1;
                page19.setImageResource(R.drawable.squid);
            }
        });
        large.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 2;
                page19.setImageResource(R.drawable.squid);
            }
        });
        rt_none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 3;
                page19.setImageResource(R.drawable.squid);
            }
        });
        pendant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ring_type = 4;
                page19.setImageResource(R.drawable.squid);
            }
        });
        /*sheathing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 1;
            }
        });*/
        /*zone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                size = 0;
            }
        });*/

        //포자 색상
        sp_buff = (Button) findViewById(R.id.sp_buff);
        sp_choco = (Button) findViewById(R.id.sp_choco);
        sp_black = (Button) findViewById(R.id.sp_black);
        sp_brown = (Button) findViewById(R.id.sp_brown);
        sp_orange = (Button) findViewById(R.id.sp_orange);
        sp_green = (Button) findViewById(R.id.sp_green);
        sp_purple = (Button) findViewById(R.id.sp_purple);
        sp_white = (Button) findViewById(R.id.sp_white);
        sp_yellow = (Button) findViewById(R.id.sp_yellow);

        page20 = (ImageView) findViewById(R.id.page20); //사진

        sp_buff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 0;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_choco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 1;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_black.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 2;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_brown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 3;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 4;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 5;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 6;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_white.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 7;
                page20.setImageResource(R.drawable.squid);
            }
        });
        sp_yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                spore_print_color = 8;
                page20.setImageResource(R.drawable.squid);
            }
        });

        //개체군
        abundant = (Button) findViewById(R.id.abundant);
        clustered = (Button) findViewById(R.id.clustered);
        numerous = (Button) findViewById(R.id.numerous);
        scattered = (Button) findViewById(R.id.scattered);
        several = (Button) findViewById(R.id.several);
        solitary = (Button) findViewById(R.id.solitary);

        page21 = (ImageView) findViewById(R.id.page21); //사진

        abundant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 0;
                page21.setImageResource(R.drawable.squid);
            }
        });
        clustered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 1;
                page21.setImageResource(R.drawable.squid);
            }
        });
        numerous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 2;
                page21.setImageResource(R.drawable.squid);
            }
        });
        scattered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 3;
                page21.setImageResource(R.drawable.squid);
            }
        });
        several.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 4;
                page21.setImageResource(R.drawable.squid);
            }
        });
        solitary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                population = 5;
                page21.setImageResource(R.drawable.squid);
            }
        });

        //발견 장소
        woods = (Button) findViewById(R.id.woods);
        grasses = (Button) findViewById(R.id.grasses);
        leaves = (Button) findViewById(R.id.leaves);
        meadows = (Button) findViewById(R.id.meadows);
        paths = (Button) findViewById(R.id.paths);
        urban = (Button) findViewById(R.id.urban);
        waste = (Button) findViewById(R.id.waste);

        page22 = (ImageView) findViewById(R.id.page22); //사진

        woods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 0;
                page22.setImageResource(R.drawable.squid);
            }
        });
        grasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 1;
                page22.setImageResource(R.drawable.squid);
            }
        });
        leaves.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 2;
                page22.setImageResource(R.drawable.squid);
            }
        });
        meadows.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 3;
                page22.setImageResource(R.drawable.squid);
            }
        });
        paths.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 4;
                page22.setImageResource(R.drawable.squid);
            }
        });
        urban.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 5;
                page22.setImageResource(R.drawable.squid);
            }
        });
        waste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                habit = 6;
                page22.setImageResource(R.drawable.squid);
            }
        });


        //이전 다음 감별 버튼
        before.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipper.showPrevious();
                count--;
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flipper.showNext();
                if (count == 0) {
                    before.setVisibility(View.VISIBLE);
                }
                count++;
                if (count == 20) {
                    next.setVisibility(View.GONE);
                    result.setVisibility(View.VISIBLE);
                }

            }
        });
        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LastActivity.class);
                String str = shape + "," + surface + "," + color + "," + bruise + "," + odor + "," + attachment + "," + spacing + "," + size + "," + g_color + "," + s_shape + "," + root + "," + stalk_above_ring + "," + stalk_below_ring + "," + sc_above_ring + "," + sc_below_ring + "," + veil_type + "," + veil_color + "," + ring_number + "," + ring_type + "," + spore_print_color + "," + population + "," + habit;
                intent.putExtra("value", str);
                startActivity(intent);
            }
        });
    }
}
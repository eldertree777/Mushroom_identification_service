package com.example.mushroom;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LastActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.last);
        setTitle("last");

        Button result = (Button) findViewById(R.id.eat);
        EditText test00 = (EditText)findViewById(R.id.test001);

        String value = getIntent().getStringExtra("value");
        //Toast.makeText(this.getApplicationContext(),value, Toast.LENGTH_SHORT).show();
        String restapi = "http://192.168.0.5:8000/predict/"; // 3%2C4%2C5
        restapi = restapi + value;
        test00.setText(restapi);
        String resultt = "bad";

        try {
            // Open the connection
            URL url = new URL(restapi);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            InputStream is = conn.getInputStream(); // ??


            // Get the stream
            StringBuilder builder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }

            // Set the result
            resultt = builder.toString();
        }
        catch (Exception e) {
            // Error calling the rest api
            Log.e("REST_API", "GET method failed: " + e.getMessage());
            e.printStackTrace();
        }

        //test00.setText(resultt);
        //Toast.makeText(this.getApplicationContext(),resultt, Toast.LENGTH_SHORT).show();

        result.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }

}
